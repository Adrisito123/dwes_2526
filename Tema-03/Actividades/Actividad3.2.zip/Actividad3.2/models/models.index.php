<?php
// models/model.index.php

$libros = [
    [
        "id" => 1,
        "titulo" => "Los Señores del tiempo",
        "autor" => "García Sénz de Urturi",
        "genero" => "Novela",
        "precio" => 19.50
    ],
    [
        "id" => 2,
        "titulo" => "El Rey recibe",
        "autor" => "Eduardo Mendoza",
        "genero" => "Novela",
        "precio" => 20.50
    ],
    [
        "id" => 3,
        "titulo" => "Diario de una mujer",
        "autor" => "Eduardo Mendoza",
        "genero" => "Juvenil",
        "precio" => 12.95
    ],
    [
        "id" => 4,
        "titulo" => "El Quijote de la Mancha",
        "autor" => "Miguel de Cervantes",
        "genero" => "Novela",
        "precio" => 15.95
    ]
];